# Constraints

No board-specific XDC file was supplied with the project document.

Before programming an FPGA board, add an `.xdc` file containing:
- Clock pin and clock period
- Reset input
- Activity input
- Optional LED/output pins

The exact constraints depend on the FPGA development board.
